# prisma-cloud-ansible
Ansible collection for Prisma Cloud
